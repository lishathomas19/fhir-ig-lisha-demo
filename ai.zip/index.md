# Home - Lisha Demo Implementation Guide v0.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/demo-ig/ImplementationGuide/demo.ig | *Version*:0.0.1 |
| Active as of 2025-12-18 | *Computable Name*:DemoImplementationGuide |

# Demo IG

This is my first FHIR Implementation Guide.

It includes one example Patient resource.

