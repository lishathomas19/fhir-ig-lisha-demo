# Home - Lisha Demo Implementation Guide v0.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://lishathomas19.github.io/fhir-ig-lisha-demo/ImplementationGuide/demo.ig | *Version*:0.0.1 |
| Active as of 2025-12-23 | *Computable Name*:DemoImplementationGuide |

# Demo IG

This is my first FHIR Implementation Guide.

It includes one example Patient resource.

